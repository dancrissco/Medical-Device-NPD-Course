# Intended Use and Indications for Use

## 1. Intended Use

## 2. Indications for Use

## 3. Limitations / Contraindications

## 4. Operating Principle Summary

## 5. Expected Benefits
