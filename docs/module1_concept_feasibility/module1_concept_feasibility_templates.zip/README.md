# Module 1: Concept & Feasibility Templates

This folder contains Markdown templates for documenting the Concept and Feasibility phase of the Medical Device Product Development course.

Each file corresponds to a deliverable outlined in Module 1:
- problem_statement.md
- intended_use.md
- market_survey.md
- tech_scan.md
- standards_and_risks.md
- design_plan_draft.md
- feasibility_report.md
